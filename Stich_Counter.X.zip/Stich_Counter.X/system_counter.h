unsigned int key_scan( void );
